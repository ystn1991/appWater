import { StyleSheet, Text, View, ScrollView, TextInput, TouchableOpacity } from 'react-native'
import React, { useState, useEffect } from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage';
import init from 'react_native_mqtt';

let message = '';
let topicPub = 'inMsg64035885';
let topicPubA = 'TankA';
let topicPubB = 'TankB';
let topicPubC = 'TankC';
let TankA = 'tank1';
let TankB = 'tank2';
let TankC = 'tank3';

// Create a client instance
init({
    size: 10000,
    storageBackend: AsyncStorage,
    defaultExpires: 1000 * 3600 * 24,
    enableCache: true,
    sync: {}
});
const options = {
    host: 'broker.emqx.io',
    port: 8083,
    id: 'id_2' + parseInt(Math.random() * 100000)
};
client = new Paho.MQTT.Client(options.host, options.port, options.id);

const Planner = (props) => {
    const [selectTank, setSelectTank] = useState();
    const [productSections, setProductSections] = useState(3);
    const [sectionQuantity, setSectionQuantity] = useState("1");
    const [inValue, setInvalue] = useState(Array(3).fill(''));
    const [productValue, setProductValue] = useState(Array(3).fill(''));
    const [waterTotal, setWaterTotal] = useState();
    const [levelA, setLevelA] = useState('XX');
    const [levelB, setLevelB] = useState('XX');
    const [levelC, setLevelC] = useState('XX');
    // var waterTotal = productValue.reduce((acc, curr) => acc + (parseInt(curr) || 0), 0)
    const data = { selectTank: selectTank, inValue: inValue, waterTotal: waterTotal };
    // console.log(data);
    // setWaterTotal(productValue.reduce((acc, curr) => acc + (parseInt(curr) || 0), 0))

    // console.log(waterTotal)

    useEffect(() => {
        client.connect({ onSuccess: onConnect });
        console.log("connect success");
        if (props.route.params !== undefined && props.route.params !== null) {
            setSelectTank(props.route.params.selectTank)
        }
    }, [props.route.params]);

    const onConnect = () => {
        console.log("onConnect");
        client.subscribe(TankA);
        client.subscribe(TankB);
        client.subscribe(TankC);
        message = new Paho.MQTT.Message("Mobile2-CPE451");
        message.destinationName = topicPub;
        client.send(message);
    }

    const sendMessage = (msg) => {
        // if (status === 'connected') {
        message = new Paho.MQTT.Message(msg);
        if (selectTank === topicPubA) {
            message.destinationName = topicPubA;
            client.send(message);
        }
        else if (selectTank === topicPubB) {
            message.destinationName = topicPubB;
            client.send(message);
        }
        else if (selectTank === topicPubC) {
            message.destinationName = topicPubC;
            client.send(message);
        }
        // message.destinationName = topicPub;
        // client.send(message);
        // }
        // else console.log('connection error');
    }

    const checkCircleColor = (circleName) => {
        if (selectTank === circleName) {
            return { borderColor: '#009418', color: '#009418' };
        }
        return {};
    };

    const onMessageArrived = (message) => {
        console.log("onMessageArrived:" + message.payloadString);
        if (message.destinationName === TankA) {
            setLevelA(message.payloadString);
        }
        else if (message.destinationName === TankB) {
            setLevelB(message.payloadString);
        }
        else if (message.destinationName === TankC) {
            setLevelC(message.payloadString);
        }
    }

    const onConnectionLost = (responseObject) => {
        if (responseObject.errorCode !== 0) {
            console.log('onConnectionLost:' + responseObject.errorMessage);
        }
    }
    // set callback handlers
    client.onConnectionLost = onConnectionLost;
    client.onMessageArrived = onMessageArrived;

    const addProductSections = () => {
        const quantity = parseInt(sectionQuantity);
        setProductSections(prevSections => prevSections + quantity);
        setInvalue(prevInValue => [...prevInValue, ...Array(quantity).fill('')]);
    };

    const save = () => {
        const total = productValue.reduce((acc, curr) => acc + (parseFloat(curr) || 0), 0);
        setWaterTotal(total);
        sendMessage(total.toString());
        console.log(total);
    }

    return (
        <ScrollView style={styles.container}>
            <View style={{ flex: 0.3, justifyContent: 'center' }}>
                <Text style={{ marginVertical: 16, fontSize: 30, color: "#000" }}>{selectTank}</Text>
                <View style={styles.headerContent}>
                    <TouchableOpacity style={[styles.circle, checkCircleColor('TankA')]} onPress={() => setSelectTank("TankA")}>
                        <Text style={[checkCircleColor('TankA'), {fontSize: 24}]}>Tank A</Text>
                        <Text>{levelA} L</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.circle, checkCircleColor('TankB')]} onPress={() => setSelectTank("TankB")}>
                        <Text style={[checkCircleColor('TankB'), {fontSize: 24}]}>Tank B</Text>
                        <Text>{levelB} L</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.circle, checkCircleColor('TankC')]} onPress={() => setSelectTank("TankC")}>
                        <Text style={[checkCircleColor('TankC'), {fontSize: 24}]}>Tank C</Text>
                        <Text>{levelC} L</Text>
                    </TouchableOpacity>
                </View>
            </View>
            <View style={{ flex: 0.7 }}>
                {[...Array(productSections)].map((_, index) => (
                    <View key={index} style={{ paddingHorizontal: 24, paddingVertical: 8 }}>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <Text>Product {index + 1}: </Text>
                            <TextInput
                                value={inValue[index] || ''}
                                onChangeText={(text) => {
                                    const newInValue = [...inValue];
                                    newInValue[index] = text;
                                    setInvalue(newInValue);
                                }}
                                placeholder={`โปรดใส่ชื่อของสินค้า ${index + 1}`}
                            />

                        </View>
                        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: 'center' }}>
                            <TextInput
                                style={styles.input}
                                placeholder='ปริมาณน้ำ'
                                value={productValue[index] || ''}
                                keyboardType="numeric"
                                onChangeText={(text) => {
                                    const newInValue = [...productValue];
                                    newInValue[index] = text;
                                    setProductValue(newInValue);
                                }}
                            />
                        </View>
                        {/* <Text style={{ left: 80 }}>(ปริมาณน้ำที่ต้องการ xx L)</Text> */}
                    </View>
                ))}
                <View style={{ flexDirection: "row", marginTop: 16, justifyContent: 'center' }}>
                    <TextInput
                        style={styles.inputQuantity}
                        placeholder="Quantity"
                        keyboardType="numeric"
                        value={sectionQuantity}
                        onChangeText={setSectionQuantity}
                    />
                    <TouchableOpacity style={styles.addSectionButton} onPress={addProductSections}>
                        <Text style={{ color: "#fff" }}>Add Sections</Text>
                    </TouchableOpacity>
                </View>
                <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 16, }}>
                    <Text>ปริมาณน้ำที่ต้องการทั้งหมด: {productValue.reduce((acc, curr) => acc + (parseFloat(curr) || 0), 0)} L</Text>
                </View>
                <View style={{ marginTop: 16, paddingHorizontal: 24 }}>
                    <View style={styles.submit}>
                        <TouchableOpacity style={styles.btnSubmit} onPress={() => save()}>
                            <Text style={{ color: "#fff", fontSize: 20, fontWeight: 'bold' }}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </ScrollView>
    )
}

export default Planner

const styles = StyleSheet.create({
    container: {
        flex: 1, 
        // paddingTop: 8, 
        paddingBottom: 16,
        paddingLeft: 16,
        paddingRight: 16,
        backgroundColor: "#fff"
    },
    headerContent: {
        flexDirection: "row",
        justifyContent: 'space-between',
        alignItems: 'center',
        // paddingVertical: 8,
    },
    circle: {
        borderWidth: 1,
        borderRadius: 100,
        width: 120,
        height: 120,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: "#5DCCFC",
        backgroundColor: '#EAF8FE'
    },
    input: {
        borderWidth: 1,
        borderRadius: 10,
        borderColor: "#ddd",
        width: 320,
        paddingLeft: 16,
        backgroundColor: "#E8E8E8"
    },
    inputQuantity: {
        borderWidth: 1,
        borderRadius: 10,
        borderColor: "#ddd",
        width: 100,
        paddingLeft: 16,
        backgroundColor: "#E8E8E8"
    },
    confirm: {
        backgroundColor: '#009418',
        padding: 10,
        borderRadius: 8
    },
    addSectionButton: {
        backgroundColor: '#5DCCFC',
        padding: 10,
        borderRadius: 8,
        marginLeft: 10,
        justifyContent: 'center',
        alignItems: 'center'
    },
    submit: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 16,
        marginBottom: 24,
    },
    btnSubmit: {
        borderWidth: 1,
        borderRadius: 10,
        borderColor: "#ddd",
        width: 250,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#5DCCFC'
    }
})
